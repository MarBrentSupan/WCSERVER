//Mar Brent Supan
//2075 - WCSERVER
//Creating a server

var http = require('http');
var server = http.createServer(function(req, res){

});

server.listen(5000);