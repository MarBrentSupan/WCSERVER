//Mar Brent Supan
//2075 - WCSERVER



function Display(x) {
    console.log(x);
}

Display(100);